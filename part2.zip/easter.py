#!/usr/bin/python3

import cgi, cgitb, os




def Easter(y):
    a = y % 19
    b = y // 100
    c = y % 100
    d = b // 4
    e = b % 4
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    j = c // 4
    k = c % 4
    m = (a + 11 * h) // 319
    r = (2 * e + 2 * j - k - h + m + 32) % 7
    n = (h - m + r + 90) // 25
    p = (h - m + r + n + 19) % 32
    #return f"{p}/{n}/{y}"
    return p,n,y

def Full_date(p,n):

    months = ["January","February","March","April","May","June","July","August","September","October","November","December"]
    month = months[n-1]
    if p == 1 or p == 21 or p == 31:
        print('%s<sup>st</sup>'%p)
    elif p == 2 or p == 22:
        print('%s<sup>nd</sup>'%p)
    elif p == 3 or p == 23:
        print('%s<sup>rd</sup>'%p)
        superscript = "rd"
    else:
        print('%s<sup>th</sup>'%p)
    print(month,y)





cgitb.enable()
form = cgi.FieldStorage()
format = form.getvalue("format")
year = form.getvalue("getYear")


print('Content-Type: text/html; charset=utf-8')
print('')
print('<!DOCTYPE html>')
print('<html>')
print('<head> <title> Python script to output date in correct format </title> </head>')
print('<body>')
#print('<p>.........</p>')


#print('format: %s <br/>' % format)
#print('year: %s <br/>' % year)

date = Easter(int(year))


p = date[0]
n = date[1]
y = date[2]
#print(p)
#print(n)
#print(y)
if format == "numerically":
    print(f"{p}/{n}/{y}")
elif format == "verbosely":
    Full_date(p,n)
else:
    print(f"{p}/{n}/{y}<br/>")
    Full_date(p,n)









print('</body>')
print('</html>')
